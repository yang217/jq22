##PixelKit UI Kits sponsored by [BitBlox.me](http://www.bitblox.me/)

![ScreenShot](https://github.com/Pixelkit/PixelKit-Bootstrap-UI-Kits/blob/master/static/04839f02a8.jpg)

[BitBlox](http://www.bitblox.me) is a new platform when you can create your site by adding pre-made design elements called blocks. 
You can visit BitBlox.me and we-d love to hear your thoughts. 

## Links

+ [BitBlox Demo](http://bit.ly/29iPNxp)
+ [BitBlox Homepage](http://www.bitblox.me/)
+ [BitBlox Themes](http://www.bitblox.me/themes)

## Funky Tunes

![ScreenShot](http://pixelkit.com/free-ui-kits/funky-tunes/funky-tunes.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/funky-tunes/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/music-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/funky-tunes/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/funky-tunes/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/music-ui-kit/)

## Skinny Frames

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/11/Slider_1_SkinnyFrames.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/skinny-frames/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/modern-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/skinny-frames/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/skinny-frames/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/modern-ui-kit/)

## City Break

![ScreenShot](http://pixelkit.com/free-ui-kits/city-break/city-break.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/city-break/> The complete Bootstrap UI kit that contains tons of additional elements spread across 5 categories is available on PixelKit.com <http://pixelkit.com/kits/hotel-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/city-break/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/city-break/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/hotel-ui-kit/)

## Chubby Stacks

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/07/01.TheBasics.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/chubby-stacks/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/fresh-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/chubby-stacks/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/chubby-stacks/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/fresh-ui-kit/)

## Sweet Candy

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/05/The-Basics1.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/sweet-candy/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/colorful-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/sweet-candy/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/sweet-candy/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/colorful-ui-kit/)

## Arctic Sunset

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/04/The-Basics.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/arctic-sunset/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/clean-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/arctic-sunset/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/arctic-sunset/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/clean-ui-kit/)

## Dark Velvet

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/05/01.Basics1.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/dark-velvet/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/dark-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/dark-velvet/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/dark-velvet/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/dark-ui-kit/)

## Vanilla Cream

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/05/The-Basics.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/vanilla-cream/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/light-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/vanilla-cream/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/vanilla-cream/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/light-ui-kit/)

## Metro Vibes

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/10/metro-vibes.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/metro-vibes/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/metro-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/metro-vibes/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/metro-vibes/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/metro-ui-kit/)

## Modern Touch

![ScreenShot](http://pixelkit.com/wp-content/uploads/2013/07/TheBasics.jpg)

To get started check out our free sample demo <http://pixelkit.com/free-ui-kits/modern-touch/> The complete Bootstrap UI kit that contains tons of additional elements spread across 6 categories is available on PixelKit.com <http://pixelkit.com/kits/flat-ui-kit/>

## Links

+ [Demo page](http://pixelkit.com/free-ui-kits/modern-touch/)
+ [Documentation page](http://pixelkit.com/free-ui-kits/modern-touch/docs/)
+ [Premium Version of this UI Kit](http://pixelkit.com/kits/flat-ui-kit/)

## Changelog

+ 1.9 Added new kit Funky Tunes.
+ 1.8 Added new kit Skinny Frames.
+ 1.7 Added new kit City Break.
+ 1.6 Added new kit Chubby Stacks.
+ 1.5 Added new kit Sweet Candy.
+ 1.4 Added new kit Arctic Sunset.
+ 1.3 Added new kit Dark Velvet.
+ 1.2 Added new kit Vanilla Cream.
+ 1.1 Added new kit Metro Vibes.
+ 1.0 First Release.
 
## About US
 
Our Shop: [http://pixelkit.com/](http://pixelkit.com)

Affiliate Program (earn money): [http://pixelkit.com/affiliates/](http://pixelkit.com/affiliates/)

Social Media:

Twitter: [http://www.twitter.com/pixelkitcom](http://www.twitter.com/pixelkitcom)

Facebook: [http://www.facebook.com/pixelkitcom](http://www.facebook.com/pixelkitcom)

## License

Free PixelKit Bootstrap UI Kits is licensed under a MIT License - http://opensource.org/licenses/mit-license.html. 

You are allowed to use these elements anywhere you want, however we’ll highly appreciate if you will link to our website when you share them - http://pixelkit.com

Thanks for supporting and enjoy!
